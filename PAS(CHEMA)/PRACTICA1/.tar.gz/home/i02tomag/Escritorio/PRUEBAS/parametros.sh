#!/bin/bash
argumento1="$*"
argumento2="$@"
echo"$#; $1; $2; $0; argumento1; argumento2"
