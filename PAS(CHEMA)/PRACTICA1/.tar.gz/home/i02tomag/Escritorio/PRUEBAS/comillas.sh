#!/bin/bash
var='"cadena de prueba"'
nuevavar="Valor de 'var' es $var"
echo $nuevavar
